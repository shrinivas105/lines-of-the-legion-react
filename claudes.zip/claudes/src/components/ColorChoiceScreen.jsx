// components/ColorChoiceScreen.jsx — campaign detail screen shown after
// picking Master or Club. HomeButton + AuthBar already render above this
// screen from App.jsx's sticky app-shell__topbar, so this component only
// owns the content below them: a single bordered panel (title, current
// rank, the Road to Legatus ladder, promotion progress, safety net and
// battle count), the Start Battle button, and a separate rank-info card.
import { Panel } from './Panel';
import { Button } from './Button';
import { LegionPath } from './LegionPath';
import { BattleHistory } from './BattleHistory';
import { LichessConnectButton } from './LichessConnectButton';
import { Scoring } from '../logic/scoring';
import { isConnected } from '../services/lichessAuth';
import { LEGION_RANK_PORTRAITS, LEGION_RANK_ICONS } from './rankColors';
import { IconCrossedGladius } from './RomanIcons';
import './ColorChoiceScreen.css';

const RANK_FACTS = {
  Recruit: 'The recruit still learns the discipline of the legion, one opening line at a time.',
  Legionary: 'The legionary keeps the line steady and converts small edges into lasting pressure.',
  Optio: 'The optio organizes the battle, spotting tactical ideas before the enemy can react.',
  Centurion: 'The centurion commands the field with clear plans and ruthless tempo.',
  Tribunus: 'The tribunus reads the fight like a campaign map, predicting the enemy’s next move.',
  Legatus: 'The legatus turns theory into domination, striking with precision and authority.',
};

export function ColorChoiceScreen({ app }) {
  const isMaster = app.aiSource === 'master';
  const source = isMaster ? 'master' : 'lichess';
  const merit = isMaster ? (app.legionMerits.master_merit || 0) : (app.legionMerits.lichess_merit || 0);
  const legion = Scoring.getLegionRank(merit);
  const needsLichessAuth = !isConnected();

  const prevThreshold = legion.level > 0 ? legion.thresholds[legion.level] : 0;
  const nextThreshold = legion.nextRank ? legion.thresholds[legion.level + 1] : prevThreshold;
  const span = nextThreshold - prevThreshold;
  const progressPct = legion.nextRank && span > 0
    ? Math.min(100, Math.max(0, ((merit - prevThreshold) / span) * 100))
    : 100;
  const currentRankImage = LEGION_RANK_PORTRAITS[legion.title] || '/ranks/recruit.png';
  const NextRankIcon = legion.nextRank ? LEGION_RANK_ICONS[legion.nextRank] : null;
  const currentRankInfo = {
    label: legion.title,
    text: isMaster
      ? 'A master legionnaire commands the opening lines with ruthless precision and iron discipline.'
      : 'The club legion advances through theory by steady practice, patience, and disciplined calculation.',
  };
  const currentRankFact = RANK_FACTS[legion.title]
    || 'The legion marches onward when discipline and study are kept in balance.';

  return (
    <div className={`color-choice color-choice--${isMaster ? 'master' : 'club'} page-transition`}>
      <div className="color-choice__wrap">
        <Panel className="color-choice__panel">
          <div className={`color-choice__panel-title color-choice__panel-title--${isMaster ? 'master' : 'club'}`}>
            {isMaster ? 'Masters Legion' : 'Club Legion'}
          </div>

          <div className="color-choice__rank-section">
            <div className="color-choice__hero">
              <div className="color-choice__rank-grid">
                <div className="color-choice__rank-grid-cell">
                  <div className="color-choice__rank-grid-label">Current Rank</div>
                  <div className="color-choice__rank-grid-value">
                    <span className="color-choice__rank-grid-icon" aria-hidden="true"><legion.icon /></span>
                    {legion.title}
                  </div>
                </div>
                <div className="color-choice__rank-grid-divider" aria-hidden="true" />
                <div className="color-choice__rank-grid-cell color-choice__rank-grid-cell--next">
                  <div className="color-choice__rank-grid-label">Next Rank</div>
                  <div className="color-choice__rank-grid-value color-choice__rank-grid-value--next">
                    {legion.nextRank ? (
                      <>
                        <span className="color-choice__rank-grid-icon" aria-hidden="true">{NextRankIcon && <NextRankIcon />}</span>
                        {legion.nextRank}
                      </>
                    ) : 'Highest Rank'}
                  </div>
                </div>
              </div>
            </div>

            <div className="color-choice__progress-section">
              <div className="color-choice__progress-track">
                <div className="color-choice__progress-fill" style={{ width: `${progressPct}%` }}>
                  <span className="color-choice__progress-shine" aria-hidden="true" />
                </div>
                {legion.nextRank && legion.title !== 'Recruit' && (
                  <div
                    className={`color-choice__safety-tick${progressPct >= 50 ? ' color-choice__safety-tick--reached' : ''}`}
                    title="Safety Net: past this point, a demotion resets you to the start of this rank instead of dropping you a full rank"
                  />
                )}
              </div>
              <div className="color-choice__progress-caption">
                {legion.nextRank
                  ? `${merit} / ${nextThreshold} Merit Achieved`
                  : `${merit} Merit \u2014 Highest Rank Attained`}
              </div>
            </div>
          </div>

          <div className="color-choice__progression">
            <div className="color-choice__section-heading">Career Progression (Road to Legatus)</div>
            <div className="color-choice__road">
              <LegionPath legion={legion} />
            </div>
          </div>

          <div className="color-choice__battle-history">
            <BattleHistory app={app} source={source} />
          </div>

          <div className="color-choice__panel-actions">
            <div className="color-choice__start">
              <Button variant="danger" size="lg" className="color-choice__start-btn" onClick={() => app.startBattle()}>
                <IconCrossedGladius className="color-choice__start-icon" aria-hidden="true" />
                <span className="color-choice__start-label">Start Battle</span>
              </Button>
            </div>

            <div className="color-choice__rank-info">
              <div className="color-choice__rank-info-portrait-wrap">
                <img
                  src={currentRankImage}
                  alt={legion.title}
                  className="color-choice__rank-info-portrait"
                  onError={(e) => { e.currentTarget.style.display = 'none'; }}
                />
              </div>
              <div className="color-choice__rank-info-body">
                <div className="color-choice__rank-info-title"><legion.icon className="color-choice__rank-info-icon" aria-hidden="true" /> {currentRankInfo.label}</div>
                <p className="color-choice__rank-info-text">{currentRankInfo.text}</p>
                <div className="color-choice__rank-divider" role="separator" aria-hidden="true">
                  <span className="color-choice__rank-divider-line" />
                  <span className="color-choice__rank-divider-dot" />
                  <span className="color-choice__rank-divider-line" />
                </div>
                <div className="rank-fact">
                  <div className="rank-fact-title">Did you know?</div>
                  <div className="rank-fact-text">{currentRankFact}</div>
                </div>
              </div>
            </div>
          </div>
        </Panel>

        {needsLichessAuth && (
          <div className="color-choice__notice">
            <p>
              Lines of the Legion reads live game data from Lichess's opening explorer, which now requires a
              connected account for at least some queries. If the battle ends immediately on the first move,
              connect your Lichess account below and try again.
            </p>
            <LichessConnectButton />
          </div>
        )}
      </div>
    </div>
  );
}

export default ColorChoiceScreen;
